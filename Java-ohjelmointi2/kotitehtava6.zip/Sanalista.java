import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Sanalista {

    private ArrayList<String> lista = new ArrayList <>();
    
    public Sanalista(String tiedosto){ 
        try (Scanner scanner = new Scanner(new File(tiedosto))){
            while (scanner.hasNextLine()){
                lista.add(scanner.nextLine());
            }
        } catch (Exception e){
            System.out.println("Virhe: " + e.getMessage());
        }
    }
    
    public ArrayList <String> annaSanat(){
        return lista;
    }
    
}

