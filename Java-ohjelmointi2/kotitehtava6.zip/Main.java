import static java.lang.Character.toLowerCase;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        
        boolean ok = false;
        
        do{
            try{
                System.out.println("Anna sanalistan tiedostonimi(tiedoston nimi on Sanalista.txt): ");
                String tiedosto = scanner.nextLine();
                Sanalista sanalista = new Sanalista(tiedosto);
                ArrayList<String> sanat = sanalista.annaSanat();
                Hirsipuu peli = new Hirsipuu(sanat, 6);
        
                String arvattava = peli.sana();
                char [] arvattavaKirjain = new char [arvattava.length()];
                int i = 0;
                while (i < arvattava.length()){
                    arvattavaKirjain[i] = '_';
                    if (arvattava.charAt(i) == ' '){
                        arvattavaKirjain[i] = ' ';
                    }
                    i++;
                }
                
                System.out.println("Tervetuloa pelaamaan hirsipuuta!");
                System.out.println(arvattavaKirjain);
                int arvausLkm = peli.arvauksiaOnJaljella();
                System.out.println("Arvauksia on j�ljell�: " + arvausLkm);
        
                while (arvausLkm > 0) {
                    char arvaus = kysyKirjain();
                    boolean onnistuiko = peli.arvaa(arvaus);
                    if (onnistuiko){
                        System.out.println("Oikein!");
                        for (int j = 0; j < arvattava.length(); j++){
                            if(arvattava.charAt(j) == arvaus){
                                arvattavaKirjain[j] = arvaus;
                            }
                        }
                        if(peli.onLoppu(arvattavaKirjain)){
                            System.out.println(arvattavaKirjain);
                            System.out.println("\nOnekksi olkoon, voitit pelin!");
                            System.out.println("Oikea sana on " + arvattava + "!");
                            break;
                        }
                    } else {
                        System.out.println("Kirjainta " + arvaus + " ei ole sansssa.");
                    }
                    arvausLkm = peli.arvauksiaOnJaljella();
                    System.out.println(arvattavaKirjain);
                    System.out.println("Arvauksia on j�ljell�: " + arvausLkm);
                    System.out.println("Arvatut kirjaimet: " + peli.arvaukset());
                    if (arvausLkm == 0){
                        System.out.println("\nH�visit pelin.");
                        System.out.println("Oikea sana on " + arvattava);
                    }
                    ok = true;
                }
            }catch(Exception e){
                    System.out.println("Virhe sy�tteess�.");
                    System.out.println("Virhe: " + e.getMessage());
            }
        } while (ok != true);
    }
    
    public static Character kysyKirjain(){
        
        boolean ok = false;
        
        do{
            try{
                System.out.println("Arvaa kirjain: ");
                String apu = scanner.nextLine();
                char kirjain = toLowerCase(apu.charAt(0));
                ok = true;
                return kirjain;
            }catch (Exception e){
                System.out.println("Virhe sy�tteess�.");
                System.out.println("Virhe: " + e.getMessage());
            }
        }while (ok != true);
        
        return null;
    }
}
