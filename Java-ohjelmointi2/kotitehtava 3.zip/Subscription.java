
public class Subscription {
	
	private String journal_name;
	private String subscriber_name;
	private String delivery_address;
	private double monthly_price;
	
	public Subscription(String journal_name, String subscriber_name, String delivery_address, double monthly_price) {
	    
		this.journal_name = journal_name;
		this.subscriber_name = subscriber_name;
		this.delivery_address = delivery_address;
		this.monthly_price = monthly_price;
		
	}
	
	public String getJournal_name() {
		return journal_name;
	}
	public void setJournal_name(String journal_name) {
		this.journal_name = journal_name;
	}
	public String getSubscriber_name() {
		return subscriber_name;
	}
	public void setSubscriber_name(String subscriber_name) {
		this.subscriber_name = subscriber_name;
	}
	public String getDelivery_address() {
		return delivery_address;
	}
	public void setDelivery_address(String delivery_address) {
		this.delivery_address = delivery_address;
	}
	public double getMonthly_price() {
		return monthly_price;
	}
	public void setMonthly_price(double monthly_price) {
		this.monthly_price = monthly_price;
	}
	
	void printlnvoice() {
		System.out.println("Tilauksen tyyppi: ");
		System.out.println();
		
	}
	
	void printInvoice() {
		System.out.println();
	    System.out.println("Lehden nimi:" + " " + this.journal_name);
	    System.out.println();
		System.out.println("henkil�n nimi:" + " " + this.subscriber_name);
		System.out.println();
		System.out.println("osoite:" + " " + this.delivery_address);
		System.out.println();
		System.out.println("kuukausihinta:" + " " + this.monthly_price + "e");
			
	}
	
}




