
public class RegularSubscription extends Subscription {
	
	private int subscription_rate;
	
	public RegularSubscription(String journal_name, String subscriber_name, String delivery_address, Double monthly_price, 
			 int subscription_rate) {
		super(journal_name, subscriber_name, delivery_address, monthly_price);
		this.subscription_rate = subscription_rate;
	}  
	
	public int getSubscription_rate() {
		return subscription_rate;
	}

	public void setSubscription_rate(int subscription_rate) {
		this.subscription_rate = subscription_rate;
	}
	
	void printInvoice() {
		 System.out.println("Tilauksen tyyppi:");
		 System.out.println();
		 System.out.println("Normaali tilaus.");
		 System.out.println();
		 System.out.println("Monta kuukautta tilaus kest��: " + " " + this.subscription_rate);
		 super.printInvoice();
		
	}
	
	
	
	
	
	

}


