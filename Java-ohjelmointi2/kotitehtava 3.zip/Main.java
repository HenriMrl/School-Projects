import java.util.Scanner;


public class Main {
	
	static void printSubscriptionInvoice(Subscription subs) {
		 subs.printInvoice();
		 
	 }
		
	 public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Valitse kumman tilauksen haluat tehd�: ");
		System.out.println();
		System.out.println("Normaalitilaukseen valitse sy�t� 1 ");
		System.out.println();
		System.out.println("Kestotilaukseen valitse 2 ");
	    String  y = sc.nextLine();
	    int x = Integer.parseInt(y);
	    
		System.out.println("Sy�t� tilauksen tiedot: ");
		System.out.println();
	    System.out.println("Anna lehden nimi: ");
	    String lehden_nimi = sc.nextLine();
		System.out.println("Anna tilaajan nimi: ");
		String tilaajan_nimi = sc.nextLine();
		System.out.println("Anna toimitusosoite: ");
		String toimitusosoite = sc.nextLine();
		System.out.println("Anna kuukausihinta: ");
		String temp_hinta = sc.nextLine();
        Double kuukausihinta = Double.parseDouble(temp_hinta);
		Subscription tilaus = null;
		
		if (x == 1) {
			System.out.println("Tilauksen tyyppi:");
			System.out.println();
			System.out.println("Normaali tilaus.");
			System.out.println();
			System.out.println("Anna tilauksen kesto kuukausina: ");
			System.out.println();
			int tilauksen_kesto = sc.nextInt();
			if(tilauksen_kesto > 12) {
				System.out.print("Kuukausia ei ole enemp�� kuin 12!!  ");
			}
			
			else {
				
				tilaus = new RegularSubscription(lehden_nimi, tilaajan_nimi, toimitusosoite, kuukausihinta, tilauksen_kesto);
			}
			
		} else if(x == 2) {
			System.out.println("Tilauksen tyyppi:");
			System.out.println();
			System.out.println("kestotilaus");
			System.out.println();
			System.out.println("Anna Alennusprosentti: ");
			System.out.println();
			int tilauksen_alennus = sc.nextInt();
			
			
			if(tilauksen_alennus > 100) {
				
				System.out.print("Ei voi olla yli 100 prosenttia!!");
			}
			
			else {
				
				
				tilaus = new StandingSubscription(lehden_nimi, tilaajan_nimi, toimitusosoite, kuukausihinta, tilauksen_alennus);
			}
			
			
		} else {
			System.out.println("sijoita jompikumpi vaihtoehdoista!!");
			System.exit(0);
			
		}
		
		printSubscriptionInvoice(tilaus);
		sc.close();
		
		}

}
