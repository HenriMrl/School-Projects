
public class StandingSubscription extends Subscription {
	
	private int subscription_discount;
	private double vuosihinta;

	
	public StandingSubscription(String journal_name, String subscriber_name, String delivery_address,
			double monthly_price, int subscription_discount) {
		super(journal_name, subscriber_name, delivery_address, monthly_price);
		this.subscription_discount = subscription_discount;
		Double hinta = monthly_price * 12;
		Double alennus = Double.valueOf(subscription_discount) / 100 ;
		this.vuosihinta = hinta - (alennus * hinta);
			
	}
	
	public int getSubscription_discount() {
		return subscription_discount;
	}

	public void setSubscription_discount(int subscription_discount) {
		this.subscription_discount = subscription_discount;
	}
	
	void printInvoice() {
		 int tilauksen_kesto_kuukausina = 12;
		 System.out.println();
		 System.out.println("Tilauksen tyyppi:");
		 System.out.println();
		 System.out.println("Kestotilaus.");
		 System.out.println();
		 System.out.println("Monta kuukautta tilaus kest��: " + " " + tilauksen_kesto_kuukausina);
		 System.out.println();
		 System.out.println("tilauksen alennus prosentteina: " + " " + this.subscription_discount);
		 System.out.println();
		 System.out.println("Tilauksen vuosihinta alennuksen j�lkeen: " + this.vuosihinta);
		 super.printInvoice();
		
	}

	
	
	
	

	
	}
	
	
	

