
public class Tontti {

	private String nimi;
	private String osoite;
	private Double pinta_ala;
	private Rakennus rakennus;

	public Tontti(String nimi, String osoite, Double pinta_ala) {
		this.nimi = nimi;
		this.osoite = osoite;
		this.pinta_ala = pinta_ala;
	}

	public String getNimi() {
		return nimi;
	}

	public void setNimi(String nimi) {
		this.nimi = nimi;
	}

	public String getOsoite() {
		return osoite;
	}

	public void setOsoite(String osoite) {
		this.osoite = osoite;
	}

	public Double getPinta_ala() {
		return pinta_ala;
	}

	public void setPinta_ala(Double pinta_ala) {
		this.pinta_ala = pinta_ala;
	}

	public Rakennus getRakennus() {
		return rakennus;
	}

	public void setRakennus(Rakennus a) {
		this.rakennus = a;
	}

	public void Tulosta() {
		System.out.println("Tontin tiedot: ");
		System.out.println();
		System.out.println("nimi: " + " " + this.nimi);
		System.out.println();
		System.out.println("osoite: " + " " + this.osoite);
		System.out.println();
		System.out.println("pinta-ala: " + " " + this.pinta_ala);
		this.rakennus.tyyppi_tulosta();
		this.rakennus.tulosta();

	}

}
