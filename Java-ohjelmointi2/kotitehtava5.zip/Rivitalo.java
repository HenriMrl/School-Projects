import java.util.ArrayList;

public class Rivitalo extends Rakennus {

	public Rivitalo(int asunto_maara, int huonelkm, ArrayList pinta_alat) {
		super(asunto_maara, huonelkm, pinta_alat);

	}

	public void tyyppi_tulosta() {
		System.out.println("Asunnon tyyppi: ");
		System.out.println();
		System.out.println("Rivitalo");

	}

}
