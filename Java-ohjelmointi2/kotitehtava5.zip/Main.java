import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("anna tontin nimi: ");
		String nimi_ = sc.nextLine();
		System.out.println("Anna tontin osoite:  ");
		String osoite = sc.nextLine();
		System.out.println("Anna tontin pinta-ala:  ");
		
		String pinta_ala = sc.nextLine();
	    while(Integer. parseInt(pinta_ala) < 0 ) {
	    	System.out.println("Anna positiivinen arvo!: ");
	    	pinta_ala = sc.nextLine();
	    }
	    
	    Tontti uusitontti = new Tontti(nimi_, osoite, Double.parseDouble(pinta_ala));
	    
	    System.out.println("Anna rakennuksen tiedot: ");
	    System.out.println();
	    System.out.println("Valitse asunnon tyyppi: kerrostalo, rivitalo tai omakotitalo");
	    String asunnontyyppi = sc.nextLine().trim();
	    int asuntolkm = 0;
	    Rakennus uusirakennus = null;
	   
	    
	    if (asunnontyyppi.compareTo("kerrostalo") == 0) {
	    	asuntolkm = 20;	
	   }
	    else if (asunnontyyppi.compareTo("rivitalo") == 0) {
	    	asuntolkm = 5;
	    }
	    else if (asunnontyyppi.compareTo("omakotitalo") == 0) {
	    	asuntolkm = 1;
	    }
	    else {
	    	System.out.println("Anna jokin vaihtoehdoista!");
	    }
	    
	    System.out.println();
	    System.out.println("Anna huoneiden lukum��r�");
	    String huonelkm = sc.nextLine();
	    ArrayList<Double> alat_lista = new ArrayList<>();
	    
	    for(int i = 0; i < asuntolkm; i++) {
	    	System.out.println();
		    System.out.println("Anna asunnon pinta-ala: ");
		    
		    String pinta__ala = sc.nextLine();
		    while(Integer. parseInt(pinta__ala) < 0 ) {
		    	System.out.println("Anna positiivinen arvo!");
		    	pinta__ala = sc.nextLine();
		    }
		    
		    alat_lista.add(Double. parseDouble(pinta__ala));       
	    }
	    
	    if (asunnontyyppi.compareTo("kerrostalo") == 0) {
	    	uusirakennus = new Kerrostalo(asuntolkm, Integer. parseInt(huonelkm), alat_lista);
	   }
	    else if (asunnontyyppi.compareTo("rivitalo") == 0) {
	    	uusirakennus = new Rivitalo(asuntolkm, Integer. parseInt(huonelkm), alat_lista);
	    }
	    else if (asunnontyyppi.compareTo("omakotitalo") == 0) {
	    	uusirakennus = new omakotitalo(asuntolkm, Integer. parseInt(huonelkm), alat_lista);
	    }
	    
	    
	    System.out.println("montako asukasta haluat: ");
	    String y = sc.nextLine();
	    for(int i = 0; i < Integer.parseInt(y); i++) {
	    	System.out.println("Anna nimi: ");
	    	String nimi = sc.nextLine();
	    	Asukas uusiasukas = new Asukas(nimi);
	        uusirakennus.add_asukas(uusiasukas);
	    
	}
	    uusitontti.setRakennus(uusirakennus);
	    uusitontti.Tulosta();

  }
	
}
