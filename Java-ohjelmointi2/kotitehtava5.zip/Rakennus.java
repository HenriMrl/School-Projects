import java.util.*;
import java.util.ArrayList;
import java.io.*;
import java.util.Enumeration;

public class Rakennus {

	private int asunto_maara;
	private Double pinta_ala;
	private int huonelkm;
	private ArrayList<Double> Pinta_alat;
	private Vector<Asukas> asukkaat = new Vector();

	public Rakennus(int asunto_maara, int huonelkm, ArrayList pinta_alat) {
		this.asunto_maara = asunto_maara;
		this.huonelkm = huonelkm;
		Pinta_alat = pinta_alat;
	}

	public void add_asukas(Asukas uusiasukas) {
		asukkaat.addElement(uusiasukas);

	}

	public void tyyppi_tulosta() {

	}

	public void tulosta() {
		System.out.println();
		System.out.println("Rakennuksen tiedot: ");
		System.out.println();
		System.out.println("asuntojen m��r�: " + " " + this.asunto_maara);
		System.out.println();
		System.out.println("huoneiden lukum��r�: " + " " + this.huonelkm);
		System.out.println();
		System.out.println("asuntojen pinta-alat: ");
		System.out.println();
		for (int i = 0; i < Pinta_alat.size(); i++) {
			System.out.println("pinta ala: " + Pinta_alat.get(i));
		}
		System.out.println();
		System.out.println("Asukkaiden tiedot: ");
		System.out.println();
		Enumeration<Asukas> enumeration = asukkaat.elements();
		while (enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement().getnimi());
		}

	}
}
