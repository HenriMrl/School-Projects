
public class Asukas {
	private String nimi;

	public Asukas(String nimi) {
		this.nimi = nimi;
	}

	public String getnimi() {
		return nimi;

	}

}
