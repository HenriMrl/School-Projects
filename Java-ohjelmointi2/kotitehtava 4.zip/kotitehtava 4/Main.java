import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		InsInfoContainer container = new InsInfoContainer();
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			System.out.println("Propertyn tiedot: ");
			System.out.println();
			System.out.println("Anna kiinteist�n tyyppi: ");
			String kiinteiston_tyyppi = sc.nextLine();
			System.out.println();
			System.out.println("Anna sijainti: ");
			String sijainti_paikka = sc.nextLine();
			Property uusiProperty = new Property(kiinteiston_tyyppi, sijainti_paikka);

			System.out.println("Anna vakuutusarvo: ");
			String vakuutusarvo = sc.nextLine();
			if (Double.parseDouble(vakuutusarvo) <= 0) {
				System.out.println("anna positiivinen vakuutusarvo!!");
				return;
			}
			System.out.println();
			InsuranceInfo uusi_insuranceinfo = new InsuranceInfo(Double.parseDouble(vakuutusarvo), uusiProperty);

			container.Arraylistaan_lisays(uusi_insuranceinfo);

		}
		container.tulosta_kaikki();
		System.out.print("anna numeerinen arvo: ");
		System.out.println();
		Double numeerinen_arvo = sc.nextDouble();
		System.out.println("kiinteist�t joilla on pienempi Vakuutusarvo : ");
		System.out.println();
		container.pienempi_tulostus(numeerinen_arvo);
		System.out.println("Kiinteist�t joilla on suurempi Vakuutusarvo: ");
		System.out.println();
		container.isompi_tulostus(numeerinen_arvo);
		sc.close();

	}

}
