import java.util.ArrayList;

public class InsInfoContainer {

	ArrayList<InsuranceInfo> vakuutustiedot = new ArrayList<InsuranceInfo>();

	void tulosta_kaikki() {
		for (int i = 0; i < vakuutustiedot.size(); i++) {
			vakuutustiedot.get(i).tulosta();

		}

	}

	void Arraylistaan_lisays(InsuranceInfo a) {
		vakuutustiedot.add(a);

	}

	void isompi_tulostus(Double vertaus_arvo) {
		if (vakuutustiedot.size() == 0) {
			System.out.println("ei vakuutustietoja!");
			return;
		}

		for (int i = 0; i < vakuutustiedot.size(); i++) {
			Double vertaus = vakuutustiedot.get(i).getVakuutusarvo();
			if (vertaus > vertaus_arvo) {
				vakuutustiedot.get(i).tulosta();

			}
		}
	}

	void pienempi_tulostus(Double vertaus_arvo) {
		if (vakuutustiedot.size() == 0) {
			System.out.println("ei vakuutustietoja!");
			return;
		}
		
		for (int i = 0; i < vakuutustiedot.size(); i++) {
			Double vertaus = vakuutustiedot.get(i).getVakuutusarvo();
			if (vertaus < vertaus_arvo) {
				vakuutustiedot.get(i).tulosta();

			}
		}

	}

}
