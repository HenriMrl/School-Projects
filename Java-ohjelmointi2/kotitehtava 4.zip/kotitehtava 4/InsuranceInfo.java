
public class InsuranceInfo {
	private Double vakuutusarvo;
	private Property property;

	public InsuranceInfo(Double vakuutusarvo, Property property) {
		this.vakuutusarvo = vakuutusarvo;
		this.property = property;
	}

	public Double getVakuutusarvo() {
		return vakuutusarvo;
	}

	public void setVakuutusarvo(Double vakuutusarvo) {
		this.vakuutusarvo = vakuutusarvo;
	}

	public Property getUusiproperty() {
		return property;
	}

	public void setUusiproperty(Property uusiproperty) {
		this.property = uusiproperty;
	}

	public void tulosta() {
		String Kiinteiston_tyyppi = property.getKiinteiston_tyyppi();
		String Sijainti_paikka = property.getSijainti_paikka();
		System.out.println("tiedot: ");
		System.out.println();
		System.out.println("Kiinteist�n tyyppi: " + " " + Kiinteiston_tyyppi);
		System.out.println();
		System.out.println("SijaintiPaikka: " + " " + Sijainti_paikka);
		System.out.println();
		System.out.println("vakuutusarvo " + " " + this.vakuutusarvo);
		System.out.println();

	}

}
