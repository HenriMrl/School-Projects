
public class Property {
	private String kiinteiston_tyyppi;
	private String Sijainti_paikka;

	public Property(String kiinteiston_tyyppi, String sijainti_paikka) {

		this.kiinteiston_tyyppi = kiinteiston_tyyppi;
		Sijainti_paikka = sijainti_paikka;
	}

	public String getKiinteiston_tyyppi() {
		return kiinteiston_tyyppi;
	}

	public void setKiinteiston_tyyppi(String kiinteiston_tyyppi) {
		this.kiinteiston_tyyppi = kiinteiston_tyyppi;
	}

	public String getSijainti_paikka() {
		return Sijainti_paikka;
	}

	public void setSijainti_paikka(String sijainti_paikka) {
		Sijainti_paikka = sijainti_paikka;
	}

}
