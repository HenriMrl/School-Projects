import java.util.Scanner;

public class Main {


	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("anna tontin nimi: ");
		String nimi_ = sc.nextLine();
		System.out.println("Anna tontin leveyspiiri:  ");
		String leveys = sc.nextLine();
		System.out.println("Anna tontin pituuspiiri:  ");
		String pituus = sc.nextLine();
		System.out.println("Anna tontin pinta-ala:  ");

	    String pinta__ala = sc.nextLine();
	    while(Integer. parseInt(pinta__ala) < 0 ) {
	    	System.out.println("Anna positiivinen arvo!: ");
	    	pinta__ala = sc.nextLine();
	    }

		Tontti uusitontti = new Tontti(nimi_, leveys, pituus, Double.parseDouble(pinta__ala));

        System.out.println("Anna rakennuksen pinta-ala: ");

	    String pinta_ala = sc.nextLine();
	    while(Integer. parseInt(pinta_ala) < 0 ) {
	    	System.out.println("Anna positiivinen arvo!");
	    	pinta_ala = sc.nextLine();
	    }

	    System.out.println("Anna rakennuksen huoneiden lukum��r�: ");
	    String huonelkm = sc.nextLine();
	    Rakennus uusirakennus = new Rakennus(Double.parseDouble(pinta_ala), Integer.parseInt(huonelkm));

	    System.out.println("montako asukasta haluat: ");
	    String x = sc.nextLine();
	    for(int i = 0; i < Integer.parseInt(x); i++) {
	    	System.out.println("Anna nimi: ");
	    	String nimi = sc.nextLine();
	    	System.out.println("anna syntym�-aika:");
	    	String syntyma_aika = sc.nextLine();
	    	Asukas uusiasukas = new Asukas(nimi, syntyma_aika);
	    	uusirakennus.addAsukas(uusiasukas);

	    }
	    uusitontti.setRakennus(uusirakennus);
	    uusitontti.tulosta();
        sc.close();
    }
}
