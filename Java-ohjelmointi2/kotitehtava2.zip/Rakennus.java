import java.util.ArrayList;
import java.util.List;
public class Rakennus {
	
	private double pinta_ala;
	private int huonelkm;
	private List<Asukas> asukkaat = new ArrayList<>();

    public Rakennus(double pinta_ala, int huonelkm) {
		this.pinta_ala = pinta_ala;
		this.huonelkm = huonelkm;
    }

    public void addAsukas(Asukas a) {
    	this.asukkaat.add(a);
    }

    public double getPinta_ala() {
		return pinta_ala;
	}

    public void setPinta_ala(double pinta_ala) {
		this.pinta_ala = pinta_ala;
	}

    public int getHuonelkm() {
		return huonelkm;
	}

	public void setHuonelkm(int huonelkm) {
		this.huonelkm = huonelkm;
	}

	public List<Asukas> getAsukkaat() {
		return asukkaat;
	}

	public void setAsukkaat(List<Asukas> asukkaat) {
		this.asukkaat = asukkaat;
	}
	
	void tulosta() {
		System.out.println();
		System.out.println("RAKENNUKSEN TIEDOT: ");
		System.out.println();
	    System.out.println("pinta_ala:" + " " + this.pinta_ala);
		System.out.println("huonelkm:" + " " + this.huonelkm);
		System.out.println();
		System.out.println("ASUKKAIDEN TIEDOT: ");
		System.out.println();
		for (Asukas element : asukkaat) {
			element.tulosta();
		}
    }
}
