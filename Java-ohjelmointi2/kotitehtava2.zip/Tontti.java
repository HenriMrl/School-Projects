
public class Tontti {
	
  private String nimi_;
  private String leveys;
  private String pituus;
  private Double pinta__ala;
  private Rakennus rakennus;
  
  
  public Tontti(String nimi, String leveys, String pituus, Double pinta_ala) {
	this.nimi_ = nimi;
	this.leveys = leveys;
	this.pituus = pituus;
	this.pinta__ala = pinta_ala;
  }
  
  public Rakennus getrakennus() {
	  return rakennus;
  }
  
  public void setRakennus(Rakennus a) {
	  this.rakennus = a;
  }
  
  public String getNimi() {
	return nimi_;
  }

  public void setNimi(String nimi) {
	this.nimi_ = nimi;
  }

  public String getLeveys() {
	return leveys;
  }
  
  public void setLeveys(String leveys) {
	this.leveys = leveys;
  }
  
  public String getPituus() {
	return pituus;
  }
  
  public void setPituus(String pituus) {
	this.pituus = pituus;
  }
  
  public Double getPinta_ala() {
	return pinta__ala;
  }

  public void setPinta_ala(Double pinta_ala) {
	this.pinta__ala = pinta_ala;
  }
  
  void tulosta() {
	System.out.println();
	System.out.println("TONTIN TIEDOT: ");
	System.out.println();
  System.out.println("tontin nimi: " + " " + this.nimi_);
	System.out.println("tontin sijainti: ");
	System.out.println();
	System.out.println("leveyspiiri: " + " " + this.leveys);
	System.out.println();
	System.out.println("Pituuspiiri: " + " " + this.pituus);
	System.out.println();
	System.out.println("tontin pinta-ala: " + " " + this.pinta__ala);
	rakennus.tulosta();
  }
  
}
